<?php

$servername = "localhost";
$username = "id21433577_root";
$password = "Copo123$";
$dbname = "id21433577_copo";

?>