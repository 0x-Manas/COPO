<?php
include (__DIR__.'/../database.php');

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['table'])) {
    $table = $_GET['table'];

    // Sanitize the table name to prevent SQL injection
    $table = mysqli_real_escape_string($conn, $table);

    // SQL query to drop the table
    $query = "DROP TABLE $table";

    if (mysqli_query($conn, $query)) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Manage Table</title>
            <link rel="stylesheet" href="./style1.css"> 
        </head>
        <style>
            body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        button[type="button"] {
            font-family: 'Open Sans', sans-serif;
            background-color: #4CAF50; /* Green color */
            color: #fff; /* White text color */
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        button[type="button"]:hover {
            background-color: #357a38; /* Dark green on hover */
        }
        </style>
        <body>
        <div class="error-message">
          Table Deleted Successfully!!!
        </div><br><br>
        <button type="button" onclick="window.location.href='matrix.php'">Back</button>
        
        
        </body>
        </html>
        <?php
        
    } else {
        echo "Error dropping the table: " . mysqli_error($conn);
    }
} else {
    echo "No table name specified.";
}
?>
