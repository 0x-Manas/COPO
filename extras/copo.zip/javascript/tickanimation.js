document.addEventListener("DOMContentLoaded", function () {
    // Select the file input and the tick element
    var fileInput = document.getElementById("excel_file");
    var tickElement = document.getElementById("tick");

    // Add an event listener to the file input
    if (fileInput) {
        fileInput.addEventListener("change", function () {
            console.log("File selected");
            if (fileInput.files.length > 0) {
                // Display the tick animation element
                tickElement.style.display = "inline-block";
            } else {
                // Hide the tick animation element if no file is selected
                tickElement.style.display = "none";
            }
        });
    }
});
