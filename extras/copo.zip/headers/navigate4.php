<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    // Check if a file was uploaded
    if (isset($_FILES['excelFile']) && $_FILES['excelFile']['error'] === UPLOAD_ERR_OK) 
    {
        // Specify the path to save the uploaded file
        $uploadDir = __DIR__ . '/../uploads/';
        $uploadFile = $uploadDir . basename($_FILES['excelFile']['name']);

        // Move the uploaded file to the specified path
    if (move_uploaded_file($_FILES['excelFile']['tmp_name'], $uploadFile)) {
        $_SESSION["file_name"] = $uploadFile;  
    }
} 
else {
    // Handle the case when no file was uploaded or an error occurred
    $errorCode = $_FILES['excelFile']['error'];

    switch ($errorCode) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            // File size exceeds the maximum allowed size
            echo "Error: The uploaded file size is too large.";
            break;
        case UPLOAD_ERR_PARTIAL:
            // The file was only partially uploaded
            echo "Error: The uploaded file was only partially uploaded.";
            break;
        case UPLOAD_ERR_NO_FILE:
            // No file was uploaded
            echo "Error: No file was uploaded.";
            break;
        case UPLOAD_ERR_NO_TMP_DIR:
            // Missing temporary folder
            echo "Error: Missing temporary folder.";
            break;
        case UPLOAD_ERR_CANT_WRITE:
            // Failed to write file to disk
            echo "Error: Failed to write file to disk.";
            break;
        case UPLOAD_ERR_EXTENSION:
            // A PHP extension stopped the file upload
            echo "Error: File upload stopped by a PHP extension.";
            break;
        default:
            // Unknown error
            echo "Error: An unknown error occurred during file upload.";
            break;
    }
}
header("Location: ../MAIN.php");
exit;
}

else {
    header("Location: ../MAIN.php");
    exit;
}


?>